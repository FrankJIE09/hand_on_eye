import cv2
import numpy as np
import glob

# 手眼标定
# 设置寻找亚像素角点的参数，采用的停止准则是最大循环次数30和最大误差容限0.001
criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
# 非对称圆形标定板规格
w = 4
h = 11

# 世界坐标系中的圆心点
objp = np.zeros((w * h, 3), np.float32)
num = 0
for i in range(h):
    if i % 2 == 0:
        for j in range(w):
            objp[num, :2] = [j, i * 0.5]
            num += 1
    else:
        for j in range(w):
            objp[num, :2] = [j + 0.5, i * 0.5]
            num += 1
objp = objp * 0.02

# 储存棋盘格角点的世界坐标和图像坐标对
objpoints = []
imgpoints = []

# 加载图像
images = glob.glob('./erzhi_img_circle2/*.jpg')

# 机器人旋转矩阵和末端位置偏移量
robotRvecs = []
robottvecs = []
for i in range(48):
    data = np.load('./erzhi_T_data_circle2/T_base2ee0' + str(i) + '.npz')
    Tee2base = data['arr_0']
    Ree2base = Tee2base[:3, :3]
    tee2base = Tee2base[:3, 3]
    robotRvecs.append(Ree2base)
    robottvecs.append(tee2base)

i = 0
for fname in images:
    img = cv2.imread(fname)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ret, corners = cv2.findCirclesGrid(gray, (w, h), flags=cv2.CALIB_CB_ASYMMETRIC_GRID)
    if ret:
        print("i:", i)
        i += 1
        objpoints.append(objp)
        imgpoints.append(corners)
        cv2.drawChessboardCorners(img, (w, h), corners, ret)
        cv2.namedWindow('findCorners', cv2.WINDOW_NORMAL)
        cv2.resizeWindow('findCorners', 640, 480)
        cv2.imshow('findCorners', img)
        cv2.waitKey(200)

cv2.destroyAllWindows()

# 相机标定
print('正在计算相机标定')
ret, mtx, dist, rvecs, tvecs = cv2.calibrateCamera(objpoints, imgpoints, gray.shape[::-1], None, None)

print("ret:", ret)
print("mtx:\n", mtx)
print("dist畸变值:\n", dist)
print("rvecs旋转（向量）外参:\n", rvecs)
print("tvecs平移（向量）外参:\n", tvecs)
newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, gray.shape[::-1], 0, gray.shape[::-1])
print('newcameramtx外参', newcameramtx)

Rvecs = [cv2.Rodrigues(rvec)[0] for rvec in rvecs]

# 手眼标定
print('正在进行手眼标定')
rm2, tm2 = cv2.calibrateHandEye(robotRvecs, robottvecs, Rvecs, tvecs, method=cv2.CALIB_HAND_EYE_TSAI)
T = np.eye(4)
T[0:3, 0:3] = rm2
T[0:3, 3] = tm2.reshape(-1)
print("T_TSAI:\n", T)

rm3, tm3 = cv2.calibrateHandEye(robotRvecs, robottvecs, Rvecs, tvecs, method=cv2.CALIB_HAND_EYE_PARK)
T3 = np.eye(4)
T3[0:3, 0:3] = rm3
T3[0:3, 3] = tm3.reshape(-1)
print("T_PARK:\n", T3)

# 保存标定结果到文件
with open('hand_eye_calibration_results.txt', 'w') as f:
    f.write("相机标定结果:\n")
    f.write(f"ret: {ret}\n")
    f.write(f"内参数矩阵 (mtx):\n{mtx}\n")
    f.write(f"畸变系数 (dist):\n{dist}\n")
    f.write(f"旋转向量 (rvecs):\n{rvecs}\n")
    f.write(f"平移向量 (tvecs):\n{tvecs}\n")
    f.write(f"优化后的相机矩阵 (newcameramtx):\n{newcameramtx}\n")
    
    f.write("\n手眼标定结果 (TSAI 方法):\n")
    f.write(f"T_TSAI:\n{T}\n")
    
    f.write("\n手眼标定结果 (PARK 方法):\n")
    f.write(f"T_PARK:\n{T3}\n")

print("手眼标定结果已保存到 hand_eye_calibration_results.txt")
